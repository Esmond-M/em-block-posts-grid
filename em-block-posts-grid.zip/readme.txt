Project: github.com/Esmond-M/em-block-posts-grid](https://github.com/Esmond-M/em-block-posts-grid)<br>
Author: [esmondmccain.com](https://esmondmccain.com/)

## Features
This plugin adds a GutenBerg block labeled "EM Posts Grid" to the widgets section of the block editor. This custom block will display lastest posts in various formats.
## Installation

1. Download the latest version from [github.com/Esmond-M/em-quick-trash-deletion](https://github.com/Esmond-M/em-quick-trash-deletion/archive/master.zip)
2. Upload `em-quick-trash-deletion` zip to the `/wp-content/plugins/` directory
3. extract zip folder
4. Activate the plugin through the 'Plugins' menu in WordPress

